<?php
$dsn = 'mysql:host=localhost;dbname=port_toamasina';
$username = 'root';
$password = '';

try {
	$pdo = new PDO($dsn, $username, $password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
	die("Erreur de connexion : " . htmlspecialchars($e->getMessage()));
}
